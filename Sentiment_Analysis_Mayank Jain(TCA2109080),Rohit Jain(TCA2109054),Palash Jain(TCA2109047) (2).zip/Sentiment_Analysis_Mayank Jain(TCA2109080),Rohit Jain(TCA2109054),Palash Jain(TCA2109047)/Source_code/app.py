from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from langdetect import detect
from transformers import pipeline
from googleapiclient.discovery import build
import re
import matplotlib.pyplot as plt
import io
import base64
from datetime import datetime
import speech_recognition as sr
import numpy as np
import wave
import os
import time  # Import the time module
from pydub import AudioSegment
from pydub.utils import make_chunks

# Explicitly set the FFmpeg path - REPLACE WITH YOUR ACTUAL PATH
FFMPEG_PATH = "C:\\ffmpeg\\ffmpeg-2025-05-05-git-f4e72eb5a3-full_build\\bin\\ffmpeg.exe"
AudioSegment.converter = FFMPEG_PATH

app = Flask(__name__)

# Secret and DB Config
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://flaskuser:Ohdude%40123@localhost:3306/sentiment'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['UPLOAD_FOLDER'] = 'temp_audio'  # Create this folder
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # Limit file upload size (e.g., 16MB)

db = SQLAlchemy(app)

# Load Hugging Face Sentiment Pipeline
sentiment_pipeline = pipeline('sentiment-analysis')

# Set up YouTube API
api_key = 'AIzaSyBe8nAzuMSnTiK_r9Aldktz2hyuyUAoutw'
youtube = build('youtube', 'v3', developerKey=api_key)

# ----------- MODELS -------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(255), unique=True, nullable=False)
    email = db.Column(db.String(255), nullable=False)
    password = db.Column(db.String(255), nullable=False)

class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), nullable=False)
    message = db.Column(db.Text, nullable=False)

    def __repr__(self):
        return f'<Feedback {self.id} from {self.name}>'

class SentimentHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    input_text = db.Column(db.Text, nullable=False)
    sentiment = db.Column(db.String(50), nullable=False)
    confidence = db.Column(db.String(50), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', backref=db.backref('history', lazy=True))

@app.before_request
def create_tables():
    db.create_all()

# ----------- UTILITY FUNCTIONS -------------
def predict_sentiment(text):
    try:
        lang = detect(text)
    except:
        lang = 'en'

    if lang in ['en', 'hi']:
        result = sentiment_pipeline(text)[0]
        label = result['label']
        score = result['score']

        if label == 'POSITIVE':
            return 'Positive', f'Confidence: {round(score * 100, 2)}%'
        elif label == 'NEGATIVE':
            return 'Negative', f'Confidence: {round(score * 100, 2)}%'
        else:
            return 'Neutral', f'Confidence: {round(score * 100, 2)}%'
    else:
        return 'Neutral', 'Language not supported, defaulted to Neutral'

def extract_video_id(url):
    match = re.search(r"v=([a-zA-Z0-9_-]{11})", url)
    return match.group(1) if match else None

def get_video_comments(video_id):
    comments = []
    try:
        request = youtube.commentThreads().list(
            part='snippet',
            videoId=video_id,
            maxResults=100
        )
        response = request.execute()

        for item in response['items']:
            comment = item['snippet']['topLevelComment']['snippet']['textDisplay']
            comments.append(comment)
    except Exception as e:
        print(f"Error fetching YouTube comments: {e}")
    return comments

def transcribe_audio(audio_file_path):
    r = sr.Recognizer()
    print(f"Attempting to transcribe audio file: {audio_file_path}")
    try:
        # Convert any supported audio to WAV first
        try:
            audio = AudioSegment.from_file(audio_file_path)
            wav_file_path = audio_file_path + ".wav"
            audio.export(wav_file_path, format="wav")
            audio_file_path = wav_file_path # Use the converted WAV file
            print(f"Audio converted to WAV: {audio_file_path}")
        except Exception as e:
            print(f"Error during audio conversion: {e}")
            return "Error: Could not convert audio format"

        with sr.AudioFile(audio_file_path) as source:
            print("Audio file opened successfully by speech_recognition.")
            audio_data = r.record(source)
            print("Audio data recorded by speech_recognition.")
            text = r.recognize_google(audio_data)
            print(f"Transcription successful: '{text}'")
            return text
    except sr.UnknownValueError:
        print("Error: Could not understand audio (speech_recognition)")
        return "Could not understand audio"
    except sr.RequestError as e:
        print(f"Error: Could not request results from speech recognition service (speech_recognition); {e}")
        return f"Could not request results from speech recognition service; {e}"
    except FileNotFoundError:
        print(f"Error: Audio file not found (speech_recognition): {audio_file_path}")
        return "Error: Audio file not found"
    except Exception as e:
        print(f"An unexpected error occurred during transcription (speech_recognition): {e}")
        return f"Error during transcription: {e}"  # Return the specific error message

@app.route('/record_voice', methods=['POST'])
def record_voice():
    if 'audio' not in request.files:
        return jsonify({"status": "recording failed", "error": "No audio file part in the request"}), 400

    audio_file = request.files['audio']
    if audio_file.filename == '':
        return jsonify({"status": "recording failed", "error": "No selected audio file"}), 400

    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])

    filename = os.path.join(app.config['UPLOAD_FOLDER'], f"recorded_audio_{int(time.time())}")
    try:
        file_extension = audio_file.filename.rsplit('.', 1)[1].lower() if '.' in audio_file.filename else ''
        full_filename = filename + '.' + file_extension
        audio_file.save(full_filename)
        return jsonify({"status": "recording saved", "filename": full_filename})
    except Exception as e:
        return jsonify({"status": "recording failed", "error": str(e)}), 500

@app.route('/analyze_recorded_voice', methods=['POST'])
def analyze_recorded_voice():
    audio_file = request.form['audio_file']
    print(f"Attempting to analyze audio file: {audio_file}")
    if not os.path.exists(audio_file):
        error_message = "Error: Audio file not found on server"
        print(error_message)
        return jsonify({"text": error_message, "sentiment": "Neutral", "confidence": ""}), 404

    try:
        transcribed_text = transcribe_audio(audio_file)
        print(f"Transcribed text: '{transcribed_text}'")
        if "Could not understand audio" not in transcribed_text and not transcribed_text.startswith("Error"):
            sentiment, confidence = predict_sentiment(transcribed_text)
            print(f"Sentiment: {sentiment}, Confidence: {confidence}")
            return jsonify({"text": transcribed_text, "sentiment": sentiment, "confidence": confidence})
        else:
            return jsonify({"text": transcribed_text, "sentiment": "Neutral", "confidence": ""})
    except Exception as e:
        error_message = f"An unexpected error occurred during voice analysis: {e}"
        print(error_message)
        return jsonify({"text": error_message, "sentiment": "Neutral", "confidence": ""}), 500

@app.route('/realtime_analysis')
def realtime_analysis():
    return render_template('realtime_analysis.html') # You might want to adjust this

# ----------- ROUTES -------------
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        existing_user = User.query.filter_by(username=username).first()
        existing_email = User.query.filter_by(email=email).first()

        if existing_user:
            flash('Username already exists. Please choose another username.', 'error')
            return redirect(url_for('register'))

        if existing_email:
            flash('Email ID already exists. Please choose another email.', 'error')
            return redirect(url_for('register'))

        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, email=email, password=hashed_password)

        try:
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful! Redirecting to login...', 'success')  # Success Flash Message
            return render_template('register.html', redirect_to_login=True)  # Return the register page
        except Exception as e:
            db.session.rollback()
            flash(f"Error during registration: {e}", 'error')
            return redirect(url_for('register'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if user exists
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            # If user exists and password matches, login successful
            session['user_id'] = user.id

            return redirect(url_for('dashboard'))
        else:
            # If credentials are incorrect, show an error message
            flash('Login failed! Incorrect username or password.', 'error')
            return redirect(url_for('login'))

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('user_id', None)

    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/about')
def about():
    return render_template('Aboutus.html')

@app.route('/contact')
def contact():
    return render_template('Contact.html')

@app.route('/feedback')
def feedback():
    return render_template('Feedback.html')

@app.route('/Index')
def Index():
    return render_template('index.html')

@app.route('/account')
def account():
    if 'user_id' not in session:

        return redirect(url_for('login'))

    user = User.query.get(session['user_id'])
    return render_template('account.html', user=user)


@app.route("/analyze", methods=["POST"])
def analyze():
    if 'user_id' not in session:

        return redirect(url_for('login'))

    text = request.form["text"]
    result, summary = predict_sentiment(text)

    history = SentimentHistory(
        user_id=session['user_id'],
        input_text=text,
        sentiment=result,
        confidence=summary
    )

    try:
        db.session.add(history)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        flash(f"Error saving history: {e}", "error")

    return render_template("dashboard.html", result=result, input_text=text, summary=summary)

@app.route('/view_history')
def view_history():
    if 'user_id' not in session:
        flash('Please log in to view your history.', 'error')
        return redirect(url_for('login'))

    user_history = SentimentHistory.query.filter_by(user_id=session['user_id']).order_by(SentimentHistory.timestamp.desc()).all()
    return render_template('history.html', history=user_history)

@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    name = request.form.get('name')
    email = request.form.get('email')
    message = request.form.get('message')

    if name and email and message:
        new_feedback = Feedback(name=name, email=email, message=message)

        try:
            db.session.add(new_feedback)
            db.session.commit()
            flash('Thank you for your feedback!')
            return jsonify({'success': True}), 200
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'error': str(e)}), 500
    else:
        return jsonify({'success': False, 'error': 'Missing fields'}), 400

@app.route('/analyze_youtube', methods=['POST'])
def analyze_youtube():
    video_url = request.form.get('video_url')
    video_id = extract_video_id(video_url)

    if not video_id:
        flash("Invalid YouTube URL. Please check and try again.")
        return redirect(url_for('dashboard'))

    try:
        comments = get_video_comments(video_id)

        if not comments:
            flash("No comments found on this video.")
            return redirect(url_for('dashboard'))

        sentiment_results = []
        sentiment_count = {'positive': 0, 'negative': 0, 'neutral': 0}

        for comment in comments:
            sentiment, confidence = predict_sentiment(comment)
            sentiment_results.append({
                'comment': comment,
                'sentiment': sentiment,
                'confidence': confidence
            })
            sentiment_count[sentiment.lower()] += 1

        labels = ['Positive', 'Negative', 'Neutral']
        sizes = [sentiment_count['positive'], sentiment_count['negative'], sentiment_count['neutral']]

        fig, ax = plt.subplots()
        ax.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90, colors=['#66b3ff', '#ff6666', '#99ff99'])
        ax.axis('equal')
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        chart_data = base64.b64encode(img.getvalue()).decode('utf8')

        return render_template('youtube_analysis.html', results=sentiment_results, chart_data=chart_data)

    except Exception as e:
        flash(f"Error during YouTube analysis: {str(e)}")
        return redirect(url_for('dashboard'))

if __name__ == '__main__':
    app.run(debug=True, threaded=True)